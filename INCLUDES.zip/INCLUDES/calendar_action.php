<?php
session_start();
include(__DIR__ . '/db.php'); 

$uid = $_SESSION['uid'] ?? 0;
$bookingId = intval($_GET['id'] ?? 0);

if (!$uid || !$bookingId) {
    die("❌ Invalid request");
}

// Fetch booking details
$stmt = $conn->prepare("
    SELECT b.BookingID, b.BookingDateChosen, s.start_time, s.end_time, 
           u.name, u.email, b.Slot
    FROM slotbookings b
    JOIN slots s ON b.Slot = s.Slot
    JOIN users u ON b.UserID = u.id
    WHERE b.BookingID=? AND b.UserID=?
");
$stmt->bind_param("ii", $bookingId, $uid);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    die("❌ Booking not found");
}

// Clean username for filename
$filename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $booking['name']);

// Use BookingDateChosen for the slot date
$slotDate = date('Ymd', strtotime($booking['BookingDateChosen']));

// Final filename: Name + SlotDate
$finalFilename = "{$filename}_{$slotDate}_booking.ics";

// Build event details
$eventStart = date("Ymd\THis", strtotime($booking['BookingDateChosen'] . " " . $booking['start_time']));
$eventEnd   = date("Ymd\THis", strtotime($booking['BookingDateChosen'] . " " . $booking['end_time']));
$eventUid   = uniqid();
$eventName  = "Study Slot - " . $booking['Slot'] . " (" . date("Y-m-d", strtotime($booking['BookingDateChosen'])) . ")";
$eventDesc  = "Your booked study slot at EduAxis.\nName: {$booking['name']}\nEmail: {$booking['email']}";
$eventLoc   = "EduAxis Study Centre";

// ICS Content
$ics = "BEGIN:VCALENDAR\r\n";
$ics .= "VERSION:2.0\r\n";
$ics .= "CALSCALE:GREGORIAN\r\n";
$ics .= "BEGIN:VEVENT\r\n";
$ics .= "DTSTART:$eventStart\r\n";
$ics .= "DTEND:$eventEnd\r\n";
$ics .= "SUMMARY:" . addslashes($eventName) . "\r\n";
$ics .= "DESCRIPTION:" . addslashes($eventDesc) . "\r\n";
$ics .= "LOCATION:" . addslashes($eventLoc) . "\r\n";
$ics .= "UID:$eventUid\r\n";
$ics .= "END:VEVENT\r\n";
$ics .= "END:VCALENDAR\r\n";

// Download headers
header('Content-Type: text/calendar; charset=utf-8');
header("Content-Disposition: attachment; filename={$finalFilename}");
echo $ics;
exit;
?>
