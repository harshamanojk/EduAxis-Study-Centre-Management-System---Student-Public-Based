<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "localhost";
$username = "root";
$password = ""; // Change this to your database password
$dbname = "eduaxis";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get logged-in user details if session exists
$thisuser = null;
$msg = "";

if (isset($_SESSION['uid'])) {
    $user_id = $_SESSION['uid'];

    $getUser = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$user_id'");

    if ($getUser && mysqli_num_rows($getUser) > 0) {
        $thisuser = mysqli_fetch_assoc($getUser);
    }
}
?>
